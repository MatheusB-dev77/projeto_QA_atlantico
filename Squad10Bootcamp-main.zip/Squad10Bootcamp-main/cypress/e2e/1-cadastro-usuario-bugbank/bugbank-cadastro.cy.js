import '../commands.js/HomeCommands';
import '../commands.js/RegisterCommands';
import { faker } from '@faker-js/faker';

const dados = {
  nome: faker.person.fullName(),        
  email: faker.internet.email(),      
  senha: faker.internet.password(8)
};

describe ('Cadastro bem-sucedido', () => {
  it ('Deve cadastrar um novo usuário com sucesso', () => {
    cy.visitarHome();
    cy.abrirTelaDeCadastro();
    cy.preencherFormularioCadastro(dados.nome, dados.email, dados.senha);
    cy.submeterCadastro();
    cy.validarCadastro(); 
  });
});

describe('Falhas no Cadastramento', () => {
  it('Não deve cadastrar usuário duplicado', () => { 

    // Primeiro cadastro
    cy.visitarHome();
    cy.abrirTelaDeCadastro();
    cy.preencherFormularioCadastro(dados.nome, dados.email, dados.senha);
    cy.submeterCadastro();
    cy.validarCadastro('foi realizado com sucesso'); // ajuste conforme necessário

    // Tentativa de duplicar
    cy.visitarHome();
    cy.abrirTelaDeCadastro();
    cy.preencherFormularioCadastro(dados.nome, dados.email, dados.senha);
    cy.submeterCadastro();
    cy.validarCadastroDuplicado()
  });

  it('Não deve cadastrar com campos vazios', () => {
    cy.visitarHome();
    cy.abrirTelaDeCadastro();
    //cy.preencherFormularioCadastro('', '', '');
    cy.submeterCadastro();
    cy.validarCamposObrigatórios()
  });
});

