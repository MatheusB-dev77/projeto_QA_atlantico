Cypress.Commands.add('preencherTransferencia', (destino, valor, digito = '') => {

  cy.get('#btn-TRANSFERÊNCIA').click()
  cy.get('input[name="accountNumber"]').type(destino)  // campo conta destino
  cy.get('input[name="digit"]').type(digito)
  cy.get('input[name="transferValue"]').type(valor) // campo valor
  cy.get('input[name="description"]').type('lalalalala')  // campo descrição (opcional)

});

Cypress.Commands.add('submeterTransferencia', () => {
  cy.get('button[type="submit"]').first().click()
});

Cypress.Commands.add('validarTransferencia', (mensagemEsperada) => {
  cy.get('.Toastify__toast-body')
    .should('be.visible')
    .and('contain', mensagemEsperada);
});


Cypress.Commands.add('realizarLogin', (email, senha) => {

  cy.contains('button', 'Acessar').should('be.visible').and('contain', 'Acessar')
  cy.get('input[name="email"]').first().type(email, {force: true})
  cy.get('input[name="password"]').first().type(senha, {force: true})
  cy.get('button[type="submit"]').first().click()

});

Cypress.Commands.add('getContaSeparada', () => {
  return cy.contains('span', /^\d{1,3}-\d$/)
    .invoke('text')
    .then((text) => {
      const [prefixo, digito] = text.split('-')
      return { prefixo, digito }
    })
    
})


Cypress.Commands.add('realizarLogoff', () => {
  cy.get('#btnExit').click()
});