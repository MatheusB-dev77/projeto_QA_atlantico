import { faker } from '@faker-js/faker';

Cypress.Commands.add('gerarDadosFake', () => {
  Cypress.env('dadosFake'), () => {
    const dados = {
      email: faker.internet.email(),
      nome: faker.name.fullName(),
      senha: faker.internet.password(8)  // senha com 8 caracteres
    };
    Cypress.env('dadosFake', dados);
  }
});

Cypress.Commands.add('preencherFormularioCadastro', (nome, email, senha) => {

  cy.get('input[name="email"]').eq(1).type(email, {force: true})
  cy.get('input[name="name"]').type(nome, {force: true})
  cy.get('input[name="password"]').eq(1).type(senha, {force: true})
  cy.get('input[name="passwordConfirmation"]').type(senha, {force: true})
  
});

Cypress.Commands.add('preencherFormularioCadastroComSaldo', (nome, email, senha) => {

  cy.get('input[name="email"]').eq(1).type(email, {force: true})
  cy.get('input[name="name"]').type(nome, {force: true})
  cy.get('input[name="password"]').eq(1).type(senha, {force: true})
  cy.get('input[name="passwordConfirmation"]').type(senha, {force: true})
  cy.get('#toggleAddBalance').click({force:true})
  
});

Cypress.Commands.add('submeterCadastro', () => {
  cy.contains('button', 'Cadastrar').click({force:true})
});

Cypress.Commands.add('validarCadastro', () => {
  cy.get('#modalText')
    .should('be.visible')
    
    cy.contains('button', 'Acessar').should('be.visible').and('contain', 'Acessar')
    cy.get('#btnCloseModal').click()
});

Cypress.Commands.add('validarCadastroDuplicado', () => {
  cy.get('#modalText')
    .should('be.visible').and('contain', 'Cadastro duplicado')
});

Cypress.Commands.add('validarCamposObrigatórios', () => {
  cy.get('.input__warging').should('contain.text', 'É campo obrigatório')

});



