Cypress.Commands.add('acessarAreaDeTransferencia', () => {  
    cy.get('[data-test="btn-transfer"]').click();
});