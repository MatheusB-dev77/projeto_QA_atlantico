Cypress.Commands.add('visitarHome', () => {
    cy.visit('https://bugbank.netlify.app/');
});

Cypress.Commands.add('abrirTelaDeCadastro', () => {
    cy.get('.ihdmxA').contains('Registrar').click();
});

Cypress.Commands.add('inserirDadosDeLogin', (email, senha) => {
    cy.abrirTelaDeLogin();
    cy.get('[data-test="email"]').type(email);
    cy.get('[data-test="password"]').type(senha);
    cy.get('.button').contains('Acessar').click();
});