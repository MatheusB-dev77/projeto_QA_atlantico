import '../commands.js/HomeCommands';
import '../commands.js/RegisterCommands';
import '../commands.js/TransferCommands';
import { faker } from '@faker-js/faker';

const dados = {
  nome: faker.person.fullName(),        
  email: faker.internet.email(),      
  senha: faker.internet.password(8)
  
  
};
describe('Teste Funcionais - Transferência', () => {
  
  it('Deve realizar uma transferência com valor positivo', () => {

    //criar conta sem saldo 
    
    cy.visitarHome();
    cy.abrirTelaDeCadastro();
    cy.preencherFormularioCadastro(dados.nome, dados.email, dados.senha);
    cy.submeterCadastro();
    cy.validarCadastro(); 

    cy.realizarLogin(dados.email, dados.senha)

    //copiar digito da conta

    cy.getContaSeparada().then(({ prefixo, digito }) => {

    // realizar logoff     

    cy.realizarLogoff()

    //Criar e loga na conta que vai mandar dinheiro
    cy.abrirTelaDeCadastro();
    cy.preencherFormularioCadastroComSaldo(2+dados.nome, 2+dados.email, dados.senha)
    cy.submeterCadastro();
    cy.validarCadastro(); 

    cy.realizarLogin(2+dados.email, dados.senha)

    //realizar transferência

    cy.preencherTransferencia(prefixo, 10, digito)
    cy.submeterTransferencia()
    cy.get('#modalText').should('contain', 'Transferencia realizada com sucesso')

    })
  });

  it('Não deve permitir transferência com valor negativo', () => {

    //criar conta sem saldo 
    
    cy.visitarHome();
    cy.abrirTelaDeCadastro();
    cy.preencherFormularioCadastro(dados.nome, dados.email, dados.senha);
    cy.submeterCadastro();
    cy.validarCadastro(); 

    cy.realizarLogin(dados.email, dados.senha)

    //copiar digito da conta

    cy.getContaSeparada().then(({ prefixo, digito }) => {

    // realizar logoff     

    cy.realizarLogoff()

    //Criar e loga na conta que vai mandar dinheiro
    cy.abrirTelaDeCadastro();
    cy.preencherFormularioCadastroComSaldo(2+dados.nome, 2+dados.email, dados.senha)
    cy.submeterCadastro();
    cy.validarCadastro(); 

    cy.realizarLogin(2+dados.email, dados.senha)

    //realizar transferência

    cy.preencherTransferencia(prefixo, -10, digito)
    cy.submeterTransferencia()
    cy.get('#modalText').should('contain', 'Valor da transferência não pode ser 0 ou negativo')

    })
  });
});
 


  it('Não deve permitir transferência com valor zero', () => {
        //criar conta sem saldo 
    
        cy.visitarHome();
        cy.abrirTelaDeCadastro();
        cy.preencherFormularioCadastro(dados.nome, dados.email, dados.senha);
        cy.submeterCadastro();
        cy.validarCadastro(); 
    
        cy.realizarLogin(dados.email, dados.senha)
    
        //copiar digito da conta
    
        cy.getContaSeparada().then(({ prefixo, digito }) => {

          // realizar logoff  
          
          cy.realizarLogoff()
    
          //Criar e loga na conta que vai mandar dinheiro
          cy.abrirTelaDeCadastro();
          cy.preencherFormularioCadastroComSaldo(2+dados.nome, 2+dados.email, dados.senha)
          cy.submeterCadastro();
          cy.validarCadastro(); 
      
          cy.realizarLogin(2+dados.email, dados.senha)
      
          //realizar transferência
      
          cy.preencherTransferencia(prefixo, 0, digito)
          cy.submeterTransferencia()
          cy.get('#modalText').should('contain', 'Valor da transferência não pode ser 0 ou negativo')
      

         })   
        })
      
 

